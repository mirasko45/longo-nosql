const categories = [
    {
        name: "Tablets",
        img: "https://consumer.huawei.com/content/dam/huawei-cbg-site/common/mkt/pdp/tablets/matepad.jpg",
    },

    {
        name: "Television",
        img: "https://images.samsung.com/is/image/samsung/kz-ru-fhd-t5300-ue43t5300auxce-frontblack-234584041?$650_519_PNG$",
    },


    {
        name: "Audio",
        img: "https://cdn.mos.cms.futurecdn.net/synrXBeZ28h8fEwmfWAVUX.jpg",
    },


    {
        name: "Phones",
        img: "https://images.unsplash.com/photo-1464380573004-8ca85a08751a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OHx8cGhvbmV8ZW58MHx8MHx3aGl0ZXw%3D&auto=format&fit=crop&w=800&q=60",
    },


    {
        name: "Aksessuars",
        img: "https://7choice.net/wp-content/uploads/2019/04/03062018mcnks49ocopy.jpg",
    },


    { name: "Laptops", img: "https://images.unsplash.com/photo-1575909812264-6902b55846ad?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" },
];

export default categories;
